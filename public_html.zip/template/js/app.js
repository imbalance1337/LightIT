$(document).ready(function() {
	console.log("OK");

	$(".reply").click(function() {
		console.log("Отвечаем на коммент: ", $(this).data("reply"));
		var commentID = $(this).data("reply");
		var msgID = $(this).data("msgid");

		if ($('.show_add_poddcomment').length > 0) {
			$(".show_add_poddcomment").remove();
		} else {

			html = '<div class="write_comment show_add_poddcomment" style="margin-left: 60px; margin-bottom: 20px; float: left">'+
						'<div class="write_avatar"><img src="' + user_avatar + '"></div>'+
						'<form onsubmit="return addPodComment(' + commentID + ', ' + msgID + ');">'+
							'<input style="width: 400px;" type="text" id="write_PodComment_text" name="comment" placeholder="Введите ответ на комментарий">'+
							'<button type="submit" class="send_comment"><i class="fa fa-reply" aria-hidden="true"></i></button>'+
						'</form>'+
					'</div>'+
					'<div class="clear"></div>';

			$('[data-commentid=' + commentID + ']').find(".podcomments").after(html);
		}
	});

});


function AddMsg() {
    var msg = $('textarea#message_text').val();
    $('#message_text').val('');
	$.ajax({
		type: 'post',
		url: '/api/message.Add.php',
		data: {
		    'user_id': user_id,
		    'message': msg
		}, //параметры запроса
		response: 'json',
		success: function(result) {
			if (result != '') {
				var res = jQuery.parseJSON(result);
				console.log(res);
				if (res.status == 'success') {
					html = '<div class="message" data-messageid="' + res.messageId + '">'+
						'<div class="avatar"><img src="' + user_avatar + '"></div>'+
						'<div class="message_content">'+
							'<div class="user_name">' + user_name + ' <br> <span class="date">только что</span></div>'+
							'<div class="user_text">' + msg + '</div>'+
						'</div>'+
						'<div class="clear"></div>'+
						'<div class="divider"></div>'+
						'<div class="message_comments"></div>'+
						'<div class="write_comment">'+
							'<div class="write_avatar"><img src="' + user_avatar + '"></div>'+
							'<form onsubmit="return addComment(' + res.messageId + ');">'+
								'<input type="text" id="write_comment_text" name="comment" placeholder="Введите комментарий">'+
								'<button type="submit" class="send_comment"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>'+
							'</form>'+
						'</div>'+
						'<div class="clear"></div>'+
					'</div>';


					$("#loadMessages").prepend(html).fadeIn(1000);
				}
			}

			
		}
	});
	return false;
}

function addComment(messageId) {
	var comment_text = $('[data-messageid=' + messageId + ']').find("#write_comment_text").val();
    $('[data-id='+messageId+']').find("#write_comment_text").val('');
    console.log(comment_text);
	$.ajax({
		type: 'post',
		url: '/api/comments.Add.php',
		data: {
		    'user_id': user_id,
		    'comment': comment_text,
		    'messageId': messageId
		}, //параметры запроса
		response: 'json',
		success: function(result) {
			var res = jQuery.parseJSON(result);
			html = '<div class="comment" data-commentid="' + res.commentId + '">'+
						'<div class="comment_avatar"><img src="' + user_avatar + '"></div>'+
						'<div class="comment_content">'+
							'<div class="user_name">' + user_name + '</div>'+
							'<div class="user_text">' + comment_text + '</div>'+
							'<div class="comment_footer">'+
								'<div class="comment_date">только что</div>'+
								'<div class="reply" data-reply="' + res.commentId + '" data-msgid="' + res.msgId + '"><i class="fa fa-reply" aria-hidden="true"></i> Ответить</div>'+
							'</div>'+
						'</div>'+	
						'<div class="clear"></div>'+
						'<div class="podcomments"></div>'				
					'</div>';
			$('[data-messageid=' + messageId + ']').find(".message_comments").append(html);

			$(".reply").click(function() {
	
				var commentID = $(this).data("reply");
				var msgID = $(this).data("msgid");

				console.log("Отвечаем на коммент: %d_%d", $(this).data("reply"), $(this).data("msgid"));

				if ($('.show_add_poddcomment').length > 0) {
					$(".show_add_poddcomment").remove();
				} else {

					html = '<div class="write_comment show_add_poddcomment" style="margin-left: 60px; margin-bottom: 20px; float: left">'+
								'<div class="write_avatar"><img src="' + user_avatar + '"></div>'+
								'<form onsubmit="return addPodComment(' + commentID + ', ' + msgID + ');">'+
									'<input style="width: 400px;" type="text" id="write_PodComment_text" name="comment" placeholder="Введите ответ на комментарий">'+
									'<button type="submit" class="send_comment"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>'+
								'</form>'+
							'</div>'+
							'<div class="clear"></div>';

					$('[data-commentid=' + commentID + ']').find(".podcomments").append(html);
				}
			});

		}
	});	
	return false;
}

function addPodComment(commentId, messageId) {
	//#write_PodComment_text
	var podcomment_text = $("#write_PodComment_text").val();
	$.ajax({
		type: 'post',
		url: '/api/comments.AddPodcomment.php',
		data: {
		    'user_id': user_id,
		    'comment': podcomment_text,
		    'commentId': commentId,
		    'messageId': messageId
		}, //параметры запроса
		response: 'json',
		success: function(result) {
			console.log(result);


			html = '<div class="podcomment" style="width: 675px; margin-left: 60px;">'+
						'<div class="comment_avatar"><img src="' + user_avatar + '"></div>'+
						'<div class="comment_content">'+
							'<div class="user_name">' + user_name + '</div>'+
							'<div class="user_text">' + podcomment_text + '</div>'+
							'<div class="comment_footer">'+
								'<div class="comment_date">только что</div>'+
							'</div>'+
						'</div>	'+
						'<div class="clear"></div>'+
					'</div>';


			$('[data-commentid=' + commentId + ']').find(".podcomments").append(html);
			$(".show_add_poddcomment").remove();
			
		}
	});	
	return false;
}

