<div class="wrapper">
	<div class="auth_block">
		<div class="title">
			<h2>Авторизация</h2>
			<p>Выберите удобный для Вас способ авторизации.</p>
		</div>

		<div class="methods">
			<a class="btn-default vk" href="/auth.php?method=vk"><i class="fa fa-vk" aria-hidden="true"></i> войти через vk</a>
			<a class="btn-default fb" href="/auth.php?method=facebook"><i class="fa fa-facebook" aria-hidden="true"></i> войти через facebook</a>
			<a class="btn-default gp" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i> войти через google+</a>
		</div>

		<div class="inform">
			Мы не храним каких-либо данных пользователя, кроме тех которые необходимые для авторизации на сайте — аватар профиля, никнейм и ссылка профиля
		</div>
	</div>
</div>
