<div class="wrapper">
	<div class="title" style="margin-top: 100px; width: 600px; ">
		<h2>Стена</h2>
		<?php if (empty($this->user['id'])): ?>
			<p>Чтобы оставить сообщение <a href="/">авторизуйтесь</a> на сайте.</p>

		<?php else : ?>
			<p>Здравствуйте, <?=$this->user['name']?>!</p>
			<p><a href="/auth.php?action=logout">Выход</a></p>
		<?php endif; ?>
	</div>

	<div class="wall">
		<?php if (!empty($this->user['id'])): ?>
		<div class="write_message">
			<form onsubmit="return AddMsg();">
				<textarea class="input-default" id="message_text" placeholder="Введите Ваше сообщение..."></textarea>
				<button type="submit" class="send_comment" style="float: right; width: 120px; font-size: 14px;">Отправить</button>
			</form>
			<div class="clear"></div>
		</div>
		<?php endif; ?>

	<div class="messages" id="loadMessages">
			<?php foreach ($this->messages as $v) : ?>
			<div class="message" data-messageid="<?= $v['id'] ?>">
				<div class="avatar"><img src="<?=$v['avatar']?>"></div>
				<div class="message_content">
					<div class="user_name"><?=$v['name']?> <br> <span class="date"><?=showDate(strtotime($v['date']));?></span></div>
					<div class="user_text"><?=$v['message']?></div>
				</div>

				<div class="clear"></div>
				<div class="divider"></div>
				
				<div class="message_comments">
					<?php foreach ($v['comments'] as $comment) : ?>
					
						<?php if (!empty($comment['owner'])): ?>
						<div class="comment" data-commentid="<?=$comment['id']?>"><!-- .comment -->
							<div class="comment_avatar"><img src="<?=$comment['avatar'];?>"></div>
							<div class="comment_content">
								<div class="user_name"><?=$comment['name'];?></div>
								<div class="user_text"><?=$comment['text'];?></div>
								<div class="comment_footer">
									<div class="comment_date"><?=showDate(strtotime($comment['date']));?></div>
									<div class="reply" data-reply="<?=$comment['id']?>" data-msgid="<?= $v['id'] ?>"><i class="fa fa-reply" aria-hidden="true"></i> Ответить</div>
								</div>

							</div>	
							<div class="clear"></div>
							
							<div class="podcomments"> <!-- .podcomments -->

								<!-- Подкомментарий -->
								<?php foreach ($comment['podcomments'] as $podcomment) : ?>
									<div class="podcomment" style="width: 675px; margin-left: 60px;">
										<div class="comment_avatar"><img src="<?=$podcomment['avatar'];?>"></div>
										<div class="comment_content">
											<div class="user_name"><?=$podcomment['name'];?></div>
											<div class="user_text"><?=$podcomment['text'];?></div>
											<div class="comment_footer">
												<div class="comment_date"><?=showDate(strtotime($podcomment['date']));?></div>
											</div>
										</div>	
										<div class="clear"></div>
									</div>
								<?php  endforeach; ?> 
								<!-- Подкомментарий -->

							</div><!-- .podcomments -->
						</div><!-- .comment -->
						<?php endif ?>
						


					<?php  endforeach; ?>		
				</div>
				
				<?php if (!empty($this->user['id'])): ?>
				<div class="write_comment">
					<div class="write_avatar"><img src="<?=$this->user['avatar']?>"></div>
					<form onsubmit="return addComment(<?= $v['id'] ?>);">
						<input type="text" id="write_comment_text" name="comment" placeholder="Введите комментарий">
						<button type="submit" class="send_comment"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
					</form>
				</div>
				<div class="clear"></div>
				<?php endif ?>
			</div>

			<?php endforeach; ?>
		</div>
	</div>
</div>
