<!DOCTYPE html>
<html>
<head>
	<title><?=$this->title?></title>

	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;subset=cyrillic" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/template/css/style.css">
	<link rel="stylesheet" type="text/css" href="/template/css/font-awesome.min.css">

	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script type="text/javascript" src="/template/js/app.js"></script>

	<?php if (!empty($this->user['id'])) : ?>
	<script type="text/javascript">
		var user_id = '<?= $this->user['id']; ?>';
		var user_avatar = '<?= $this->user['avatar']; ?>';
		var user_name = '<?= $this->user['name']; ?>';	
	</script>
	<?php endif; ?>
</head>
<body>
