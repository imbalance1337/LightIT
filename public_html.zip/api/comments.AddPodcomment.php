<?php

	#Подключаем конфигурацию
	include("../config.php");

	#Подгружаем класс include/db.class.php
	loadClass("db");

	$db = CDb::Init();

	if (!empty($_POST['user_id']) && !empty($_POST['comment']) && !empty($_POST['commentId']) && !empty($_POST['messageId'])) {

		$owner = $_POST['user_id'];
		$comment = htmlspecialchars($_POST['comment']);
		$messageId = $_POST['messageId'];
		$commentId = $_POST['commentId'];

		$addedComment = $db->query("INSERT INTO `comments` (`owner`, `comment`, `msg_id`, `comment_id`) VALUES (?, ?, ?, ?)", [$owner, $comment, $messageId, $commentId], 'id');
		$result = ["status" => "success", "commentId" => $addedComment, "msgId" => $messageId];

		echo json_encode($result);
	}
	
?>