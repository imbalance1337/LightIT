<?php

	#Подключаем конфигурацию
	include("../config.php");

	#Подгружаем класс include/db.class.php
	loadClass("db");

	$db = CDb::Init();

	if (!empty($_POST['user_id']) && !empty($_POST['message'])) {

		$owner = $_POST['user_id'];
		$message = htmlspecialchars($_POST['message']);

		$addedMessage = $db->query("INSERT INTO `messages` (`owner`, `message`) VALUES (?, ?)", [$owner, $message], 'id');
		$result = ["status" => "success", "messageId" => $addedMessage];

		echo json_encode($result);
	}
	
?>