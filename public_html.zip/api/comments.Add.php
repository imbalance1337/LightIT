<?php

	#Подключаем конфигурацию
	include("../config.php");

	#Подгружаем класс include/db.class.php
	loadClass("db");

	$db = CDb::Init();

	if (!empty($_POST['user_id']) && !empty($_POST['comment']) && !empty($_POST['messageId'])) {

		$owner = $_POST['user_id'];
		$comment = htmlspecialchars($_POST['comment']);
		$messageId = $_POST['messageId'];

		$addedComment = $db->query("INSERT INTO `comments` (`owner`, `comment`, `msg_id`) VALUES (?, ?, ?)", [$owner, $comment, $messageId], 'id');
		$result = ["status" => "success", "commentId" => $addedComment, "msgId" => $messageId];

		echo json_encode($result);
	}
	
?>