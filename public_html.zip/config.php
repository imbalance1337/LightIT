<?php

ini_set('display_errors', 0);
error_reporting(0);

session_start();
// настройки сайта
define('SITE_NAME', 'Стенка');

define('PATH', dirname(__FILE__));

#Путь к сессиям
define('SESSION_PATH', '/var/lib/php/sessions');


#Конфигурации VK
define('VK_APP_ID', 000000000);
define('VK_CLIENT_SECRET', 'XXXXXXXXXX');

#Конфигурации Facebook
define('FB_CLIENT_ID', 000000000);
define('FB_CLIENT_SECRET', 'XXXXXXXXXX');
define('FB_REDIRECT', 'http://your_domain/auth.php?method=facebook'); 


/* подключаем вспомогательный функционал */
require_once('include/functions.php');

// подключаем класс с базой
require_once('include/goDB/autoload.php'); // path to goDB
\go\DB\autoloadRegister();
?>