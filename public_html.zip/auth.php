<?php 
include("config.php");

ini_set('display_errors', 1);
error_reporting(E_ALL);

loadClass("db");
loadClass("auth");

$db = CDb::Init();
$CAuth = new Auth($db);

$method = $_GET['method'];
$action = $_GET['action'];

if ($action == 'logout') {
	logout();
}

if ($method == 'vk') {

	if (empty($_GET['code'])) {
		#Формируем ссылку
		$vk_link = $CAuth->VKGen_link();

		#Переадресовуем пользователя
		redirect($vk_link);
	} else {
		$code = $_GET['code'];
		#Получаем access_token
		$userInfo = $CAuth->Auth($code);
		if (!empty($userInfo)) {
			
			#Проверяем, есть ли такой пользователь у нас в базе?
			$checkUser = $db->query("SELECT * FROM `users` WHERE `auth_method` = 'vk' AND `social_id` = ?", [$userInfo['uid']], 'row');

			if (empty($checkUser)) {
				$idNU_vk = $db->query("INSERT INTO `users` (`name`, `avatar`, `social_id`, `auth_method`) VALUES (?, ?, ?, 'vk')", [$userInfo['name'], $userInfo['avatar'], $userInfo['uid']], 'id');
				$_SESSION['user'] = ["id" => $idNU_vk, "name" => $userInfo['name'], "avatar" => $userInfo['avatar'], "uid" => $userInfo['uid']];
			} else {
				//создать сессию
				$_SESSION['user'] = ["id" => $checkUser['id'], "name" => $checkUser['name'], "avatar" => $checkUser['avatar'], "uid" => $checkUser['social_id']];
			}

		}
		redirect('/messages.php');
	}
} elseif ($method == 'facebook') {

	if (empty($_GET['code'])) {

		#Переадресовуем пользователя
		redirect($CAuth->FB_GenLink());

	} else {

		$code = $_GET['code'];
		#Получаем access_token
		$userInfo = $CAuth->FB_Auth($code);
		if (!empty($userInfo)) {
			#Проверяем, есть ли такой пользователь у нас в базе?
			$checkUser = $db->query("SELECT * FROM `users` WHERE `auth_method` = 'facebook' AND `social_id` = ?", [$userInfo['uid']], 'row');

			if (empty($checkUser)) {
				$idNU_vk = $db->query("INSERT INTO `users` (`name`, `avatar`, `social_id`, `auth_method`) VALUES (?, ?, ?, 'facebook')", [$userInfo['name'], $userInfo['avatar'], $userInfo['uid']], 'id');
				$_SESSION['user'] = ["id" => $idNU_vk, "name" => $userInfo['name'], "avatar" => $userInfo['avatar'], "uid" => $userInfo['uid']];
			} else {
				$_SESSION['user'] = ["id" => $checkUser['id'], "name" => $checkUser['name'], "avatar" => $checkUser['avatar'], "uid" => $checkUser['social_id']];				
			}


		}
		redirect('/messages.php');
	}
}



?>