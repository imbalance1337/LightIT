<?php

function showDate( $date ) {
    $stf      = 0;
    $cur_time = time();
    $diff     = $cur_time - $date;
 
    $seconds = array( 'секунда', 'секунды', 'секунд' );
    $minutes = array( 'минута', 'минуты', 'минут' );
    $hours   = array( 'час', 'часа', 'часов' );
    $days    = array( 'день', 'дня', 'дней' );
    $weeks   = array( 'неделя', 'недели', 'недель' );
    $months  = array( 'месяц', 'месяца', 'месяцев' );
    $years   = array( 'год', 'года', 'лет' );
    $decades = array( 'десятилетие', 'десятилетия', 'десятилетий' );
 
    $phrase = array( $seconds, $minutes, $hours, $days, $weeks, $months, $years, $decades );
    $length = array( 1, 60, 3600, 86400, 604800, 2630880, 31570560, 315705600 );
 
    for ( $i = sizeof( $length ) - 1; ( $i >= 0 ) && ( ( $no = $diff / $length[ $i ] ) <= 1 ); $i -- ) {
        ;
    }
    if ( $i < 0 ) {
        $i = 0;
    }
    $_time = $cur_time - ( $diff % $length[ $i ] );
    $no    = floor( $no );
    $value = sprintf( "%d %s ", $no, getPhrase( $no, $phrase[ $i ] ) );
 
    if ( ( $stf == 1 ) && ( $i >= 1 ) && ( ( $cur_time - $_time ) > 0 ) ) {
        $value .= time_ago( $_time );
    }
 
    return $value . '  назад';
}
 
function getPhrase( $number, $titles ) {
    $cases = array( 2, 0, 1, 1, 1, 2 );
 
    return $titles[ ( $number % 100 > 4 && $number % 100 < 20 ) ? 2 : $cases[ min( $number % 10, 5 ) ] ];
}

// загрузка классов
function loadClass($classname) {
    include_once (PATH . '/include/' . $classname . '.class.php');
}

// редирект
function redirect($to) {
    header('Location: ' . $to);
    exit();
}

function getSession($key) {
    return $_SESSION[$key];
}

function setSession($key, $data) {
    $_SESSION[$key] = $data;
}

function deleteSession($key) {
    unset($_SESSION[$key]);
}

function isLogged() {
    $usr = getSession('user');
    if (!empty($usr)) {
        return true;
    }
    return false;
}



/* user functions */

function getUser() {
    return getSession('user');
}

function logout() {
    deleteSession('user');
    session_destroy();
    session_start();
    session_regenerate_id(true);
    redirect('/');
}

// проверка, установленны ли зачения
function checkParams($params) {
    $check = true;
    foreach ($params as $key => $value) {
        if (empty($_POST[$value])) {
            $check = false;
        }
    }
    return $check;
}

// получаем значения
function getRequests($params) {
    foreach ($params as $value) {
        $string = htmlspecialchars($_POST[$value], ENT_HTML5, 'UTF-8');
        $res[$value] = $string;
    }
    return $res;
}

function getMessage() {
    return $_SESSION['msg'];
}

// очистка временных сообщений
function clearMessage() {
    unset($_SESSION['msg']);
}

// установка сообщений временных сообщений
function setMessage($msg) {
    $_SESSION['msg'] = $msg;
}

// генерирует CSRF Token
function generateCSRFToken() {
    return md5(uniqid(mt_rand() . microtime()));
}

function setCSRFToken($token) {
    $_SESSION['csrf_token'] = $token;
}

function unsetCSRFToken() {
    unset($_SESSION['csrf_token']);
}

function checkCSRFToken($token) {
    if ($_SESSION['csrf_token'] == $token) {
        return true;
    }
    return false;
}

function xss_clean($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

function declension($digit, $expr, $onlyword = true) { //склонение слов
    if (!is_array($expr))
        $expr = array_filter(explode(' ', $expr));
    if (empty($expr[2]))
        $expr[2] = $expr[1];
    $i = preg_replace('/[^0-9]+/s', '', $digit) % 100;
    if ($onlyword)
        $digit = '';
    if ($i >= 5 && $i <= 20)
        $res = $digit . ' ' . $expr[2];
    else {
        $i%=10;
        if ($i == 1)
            $res = $digit . ' ' . $expr[0];
        elseif ($i >= 2 && $i <= 4)
            $res = $digit . ' ' . $expr[1];
        else
            $res = $digit . ' ' . $expr[2];
    }
    return trim($res);
}   

?>
