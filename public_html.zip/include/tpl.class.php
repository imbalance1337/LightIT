<?php

class Template {

    private $_path;
    private $_template;
    private $_var = array();

    public function __construct($subFolder = '') {
        $this->_path = PATH.'/template/';
        if ($subFolder) {
            $this->_path .= $subFolder . '/';
        }
    }

    public function __get($name) {
        if (isset($this->_var[$name]))
            return $this->_var[$name];
        return '';
    }

    public function view($template, $data = false, $header = false, $subFolder = '', $strip = true) {
        $this->_template = $this->_path . $template . '.tpl.php';
        if (!file_exists($this->_template))
            die('Template ' . $this->_template . ' not found');

        if ($data) {
            foreach ($data as $key => $value) {
                $this->_var[$key] = $value;
            }
        }

        ob_start();
        if ($header) {
            include($this->_path . 'header.tpl.php');
        }
        include($this->_template);
        if ($header) {
            @include($this->_path . 'footer.tpl.php');
        }

        echo ($strip) ? $this->_strip(ob_get_clean()) : ob_get_clean();
    }

    private function _strip($data) {
        $lit = array("\\t", "\\n", "\\n\\r", "\\r\\n", "  ");
        $sp = array('', '', '', '', '');
        return str_replace($lit, $sp, $data);
    }

    public function xss($data) {
        if (is_array($data)) {
            $escaped = array();
            foreach ($data as $key => $value) {
                $escaped[$key] = $this->xss($value);
            }
            return $escaped;
        }
        return htmlspecialchars($data, ENT_QUOTES);
    }

    function includeHeader() {
        include('header.tpl');
    }

}

?>