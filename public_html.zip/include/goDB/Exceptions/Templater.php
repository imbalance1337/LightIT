<?php
/**
 * @package go\DB
 */

namespace go\DB\Exceptions;

/**
 * Templating error
 *
 * @author Oleg Grigoriev <go.vasac@gmail.com>
 */
abstract class Templater extends Logic
{

}
