<?php
/**
 * @package go\DB
 */

namespace go\DB\Exceptions;

/**
 * Error: the incoming data for the pattern is invalid
 *
 * @author Oleg Grigoriev <go.vasac@gmail.com>
 */
abstract class Data extends Templater
{

}
