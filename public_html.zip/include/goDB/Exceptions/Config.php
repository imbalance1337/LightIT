<?php
/**
 * @package go\DB
 */

namespace go\DB\Exceptions;

/**
 * Error: a configuration is invalid
 *
 * @author Oleg Grigoriev <go.vasac@gmail.com>
 */
abstract class Config extends Logic
{

}
