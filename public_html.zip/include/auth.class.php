<?php 

/**
* Auth Class
*/
class Auth {
	
	function __construct($db = false) {
		if (!$db) {
            $db = CDb::Init();
        }
        $this->db = $db;
	}


	/**
	* Метод авторизации Вконтакте
	*/

	public function VKGen_link() {
		$url = 'http://oauth.vk.com/authorize';
		$params = [
			'client_id' => VK_APP_ID,
			'display' => 'page',
			'scope' => 'friends',
			'redirect_uri' => 'http://192.168.1.151/auth.php?method=vk',
			'response_type' => 'code',
			'v' => '5.60'
		];

		$redirectTo = $url . '?' . urldecode(http_build_query($params));
		return $redirectTo;
	}

	public function Auth($code) {
		$url = 'https://oauth.vk.com/access_token';
		$params = [
			'client_id' => VK_APP_ID,
			'client_secret' => VK_CLIENT_SECRET,
			'redirect_uri' => 'http://192.168.1.151/auth.php?method=vk',
			'code' => $code
		];

		$query = file_get_contents($url . '?' . urldecode(http_build_query($params)));
		$query_json = json_decode($query, true);

		$s = $this->VK_UserInfo($query_json['user_id'], $query_json['access_token'])['response'][0];
		
		#Формируем результат
		$result = [
			"name" => $s['first_name'] . " " . $s['last_name'],
			"avatar" => $s['photo_100'],
			"uid" => $query_json['user_id']
		];

		return $result;
	}

	private function VK_UserInfo($uid, $token) {
		$url = 'https://api.vk.com/method/users.get?user_ids=' . $uid . '&fields=photo_100&access_token=' . $token . '&v=5.60';
		$query = file_get_contents($url);
		$json = json_decode($query, true);

		return $json;
	}


	public function FB_GenLink() {
		$url = 'https://www.facebook.com/dialog/oauth';

		$params = [
		    'client_id'     => FB_CLIENT_ID,
		    'redirect_uri'  => FB_REDIRECT,
		    'response_type' => 'code',
		    'scope'         => 'email,user_birthday'
		];

		$result = $url . '?' . urldecode(http_build_query($params));
		return $result;
	}

	public function FB_Auth($code) {
		$url = 'https://graph.facebook.com/v2.8/oauth/access_token';

		$params = [
		    'client_id'     => FB_CLIENT_ID,
		    'redirect_uri'  => FB_REDIRECT,
		    'client_secret' => FB_CLIENT_SECRET,
		    'code'         => $code
		];

		$query = file_get_contents($url . '?' . urldecode(http_build_query($params)));
		$query_json = json_decode($query, true);

		$user = file_get_contents('https://graph.facebook.com/me?access_token='.$query_json['access_token']);
		$user_json = json_decode($user, true);

		$result = [
			"name" 		=> $user_json['name'], 
			"uid" 		=> $user_json['id'], 
			"avatar" 	=> 'https://graph.facebook.com/v2.8/'. $user_json['id'] .'/picture?height=150&width=150'
		];

		print_r($result);



		return $result;
	}

}

?>