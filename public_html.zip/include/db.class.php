<?php

class CDb {

    static function Init() {

        $params = array(
            'host' => 'localhost',
            'username' => 'root',
            'password' => 'root',
            'dbname' => 'reviews_db',
            'charset' => 'utf8',
            '_debug' => false
        );

        return go\DB\DB::create($params, 'mysql');
    }

}
