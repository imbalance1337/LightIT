<?php
include('config.php');

loadClass('tpl');
loadClass('db');
$TPL = new Template();
$db = CDb::Init();

$user = $_SESSION['user'];

$messages = $db->query("SELECT `messages`.`id`, `messages`.`owner`, `messages`.`message`, `messages`.`date`, `users`.`name`, `users`.`avatar` FROM `messages` INNER JOIN `users` ON(`messages`.`owner` = `users`.`id`) ORDER BY `id` DESC LIMIT 10" , null, 'assoc:id');

if (!empty($messages)) {
	foreach ($messages as $v) {
		$ids[] = $v['id'];
	}

	$str = implode(", ",$ids);

	$comments = $db->query("SELECT `comments`.`id`, `comments`.`comment_id`, `comments`.`msg_id`, `comments`.`comment`, `comments`.`date`, `comments`.`owner`, `users`.`name`, `users`.`avatar` FROM `comments` INNER JOIN `users` ON(`comments`.`owner` = `users`.`id`) WHERE `comments`.`msg_id` IN(". $str .")", null, 'assoc');


	foreach ($comments as $cmnt) {
		if (empty($cmnt['comment_id'])) {
			$messages[$cmnt['msg_id']]['comments'][$cmnt['id']] = ["owner" => $cmnt['owner'], "id" => $cmnt['id'], "text" => $cmnt['comment'], "date" => $cmnt['date'], "name" => $cmnt['name'], "avatar" => $cmnt['avatar']];
		} else {
			$messages[$cmnt['msg_id']]['comments'][$cmnt['comment_id']]['podcomments'][$cmnt['id']] = ["owner" => $cmnt['owner'], "text" => $cmnt['comment'], "date" => $cmnt['date'], "name" => $cmnt['name'], "avatar" => $cmnt['avatar']];
		}	
	}
	/*echo "<pre>";
	print_r($messages);
	echo "</pre>";*/
}





$data['title'] = "Стена";
$data['user'] = $user;
$data['messages'] = $messages;
$data['csrf_token'] = $new_token;

$TPL->view('messages', $data, true);
?>
