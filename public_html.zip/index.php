<?php
include('config.php');

#Подгрузка классов
loadClass('tpl');
$TPL = new Template();

$user = $_SESSION['user'];

if (!empty($user)) {
	redirect('/messages.php');
}

#Формируем массив для передачи шаблонизатору
$data['title'] = "Авторизация";
$data['user'] = $user;

$TPL->view('index', $data, true);
?>
